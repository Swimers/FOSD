@echo off
"%~dp0MPWavelengthSimulator.exe" --self-test
set "result=%errorlevel%"
echo.
pause
exit /b %result%
