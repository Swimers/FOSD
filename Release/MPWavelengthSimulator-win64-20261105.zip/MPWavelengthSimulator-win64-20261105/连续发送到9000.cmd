@echo off
"%~dp0MPWavelengthSimulator.exe" --port 9000 --count 0 --interval 20
pause
